const e="/relex.jpg";export{e as _};
